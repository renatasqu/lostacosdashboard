export const navSections = [
  { id: "totem", label: "Totem", sub: "Pedido do cliente", icon: "Sandwich" },
  { id: "visao-geral", label: "Visão Geral", sub: "Overview", icon: "LayoutDashboard" },
  { id: "cozinha", label: "Cozinha", sub: "Kitchen", icon: "CookingPot" },
  { id: "clientes", label: "Clientes", sub: "Customers", icon: "Users" },
  { id: "cardapio", label: "Cardápio & CMV", sub: "Menu & costs", icon: "ClipboardList" },
  { id: "financeiro", label: "Financeiro", sub: "Financial", icon: "Wallet" },
  { id: "comunicacao", label: "Comunicação", sub: "Marketing", icon: "Megaphone" },
] as const

export type SectionId = (typeof navSections)[number]["id"]

export const kpis = [
  {
    label: "Receita Total",
    value: "R$ 16.112,70",
    delta: "+12,4%",
    trend: "up" as const,
    hint: "vs. quinzena anterior",
    accent: "gold" as const,
  },
  {
    label: "Pedidos",
    value: "253",
    delta: "+8,1%",
    trend: "up" as const,
    hint: "13 dias de junho",
    accent: "pink" as const,
  },
  {
    label: "Ticket Médio",
    value: "R$ 63,69",
    delta: "+3,9%",
    trend: "up" as const,
    hint: "por pedido",
    accent: "purple" as const,
  },
  {
    label: "Melhor Dia",
    value: "Sábado",
    delta: "R$ 3.241",
    trend: "up" as const,
    hint: "08/06 · pico de vendas",
    accent: "cream" as const,
  },
]

export const revenueByDay = [
  { dia: "01", label: "Dom 01", receita: 982 },
  { dia: "02", label: "Seg 02", receita: 745 },
  { dia: "03", label: "Ter 03", receita: 1120 },
  { dia: "04", label: "Qua 04", receita: 1340 },
  { dia: "05", label: "Qui 05", receita: 1190 },
  { dia: "06", label: "Sex 06", receita: 2010 },
  { dia: "07", label: "Sáb 07", receita: 2980 },
  { dia: "08", label: "Dom 08", receita: 3241 },
  { dia: "09", label: "Seg 09", receita: 870 },
  { dia: "10", label: "Ter 10", receita: 1015 },
  { dia: "11", label: "Qua 11", receita: 1180 },
  { dia: "12", label: "Qui 12", receita: 1260 },
  { dia: "13", label: "Sex 13", receita: 1979.7 },
]

export const ordersByChannel = [
  { canal: "Totem", pedidos: 112, fill: "var(--color-totem)" },
  { canal: "Balcão", pedidos: 68, fill: "var(--color-balcao)" },
  { canal: "iFood", pedidos: 49, fill: "var(--color-ifood)" },
  { canal: "Rappi", pedidos: 24, fill: "var(--color-rappi)" },
]
